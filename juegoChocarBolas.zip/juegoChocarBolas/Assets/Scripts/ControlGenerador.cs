using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlGenerador : MonoBehaviour
{
    public GameObject prefabEnemigo;
    private float rangoGenerador = 9.0f;
    public int numeroEnemigos;
    public int numeroOleada = 1;
    public GameObject PowerUp;
    // Start is called before the first frame update
    void Start()
    {
        GeneradorEnemigos(numeroOleada);
        Instantiate(PowerUp, DamePosicionGenerador(), PowerUp.transform.rotation);
    }

    // Update is called once per frame
    void Update()
    {
        numeroEnemigos = FindObjectsOfType<Enemigo>().Length;
        if (numeroEnemigos == 0)
        {
            numeroOleada++;
            GeneradorEnemigos(numeroOleada);
            Instantiate(PowerUp, DamePosicionGenerador(), PowerUp.transform.rotation);
        }
    }
    Vector3 DamePosicionGenerador()
    {
        float posXGenerador = Random.Range(-rangoGenerador, rangoGenerador);
        float posYGenerador = Random.Range(-rangoGenerador, rangoGenerador);
        Vector3 posAleatoria = new Vector3(posXGenerador, 0, posYGenerador);
        return posAleatoria;
    }

    void GeneradorEnemigos(int enemigos)
    {
        for(int i=0; i < enemigos; i++)
        {
            Instantiate(prefabEnemigo, DamePosicionGenerador(), prefabEnemigo.transform.rotation);
        }
    }
}
