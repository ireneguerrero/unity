using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlJugador : MonoBehaviour
{
    private Rigidbody rbJugador;
    private GameObject puntoEnfoque;
    public bool tienePowerUp;
    public float velocidad = 0.5f;
    private float fuerzaPowerUp = 15.0f;
    public GameObject indicadorPowerUp;
    // Start is called before the first frame update
    void Start()
    {
        rbJugador = GetComponent<Rigidbody>();
        puntoEnfoque = GameObject.Find("Punto de Enfoque");
    }

    // Update is called once per frame
    void Update()
    {
        float entradaAvance = Input.GetAxis("Vertical");
        float entradaLateral = Input.GetAxis("Horizontal");
        rbJugador.AddForce(puntoEnfoque.transform.forward * entradaAvance * velocidad);
        rbJugador.AddForce(puntoEnfoque.transform.right * entradaLateral * velocidad);
        indicadorPowerUp.transform.position = transform.position + new Vector3(0, -0.5f, 0);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("PowerUp"))
        {
            tienePowerUp = true;
            Destroy(other.gameObject);
            Debug.Log("Ha cogido PowerUp");
            indicadorPowerUp.gameObject.SetActive(true);
            StartCoroutine(RutinaTemporizadorPowerUp());
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemigo") && tienePowerUp)
        {
            Rigidbody rbEnemigo = collision.gameObject.GetComponent<Rigidbody>();
            Vector3 lanzarEnemigo = (collision.gameObject.transform.position - transform.position);
            rbEnemigo.AddForce(lanzarEnemigo * fuerzaPowerUp, ForceMode.Impulse);
            Debug.Log("El jugador ha chocado contra " + collision.gameObject + " con el PowerUp activado");
        }
    }

    IEnumerator RutinaTemporizadorPowerUp()
    {
        yield return new WaitForSeconds(7);
        Debug.Log("Han pasado los siete segundos de tu PowerUp");
        indicadorPowerUp.gameObject.SetActive(false);
        tienePowerUp = false;
    }
}
